import express from 'express';
import {
  addReading,
  simulateReading,
  getHistory,
  getLatest,
  deleteEvent,
  exportHistory,
} from '../controllers/rainController.js';
import { protect, authorize } from '../middleware/auth.js';
import deviceAuth from '../middleware/deviceAuth.js';
import { rainEventValidation, validate } from '../middleware/validators.js';

const router = express.Router();

// Called by the physical device (Arduino/ESP32), authenticated with a device key
router.post('/add', deviceAuth, rainEventValidation, validate, addReading);

// Called by the logged-in frontend to test the system without real hardware
router.post('/simulate', protect, simulateReading);

router.get('/history', protect, getHistory);
router.get('/latest', protect, getLatest);
router.get('/export', protect, authorize('admin'), exportHistory);
router.delete('/:id', protect, authorize('admin'), deleteEvent);

export default router;

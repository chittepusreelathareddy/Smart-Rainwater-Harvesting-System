import express from 'express';
import { getAllUsers, deleteUser, getSystemStats } from '../controllers/adminController.js';
import { protect, authorize } from '../middleware/auth.js';

const router = express.Router();

router.use(protect, authorize('admin'));

router.get('/users', getAllUsers);
router.delete('/users/:id', deleteUser);
router.get('/system-stats', getSystemStats);

export default router;

// Aggregated statistics for the Dashboard and Analytics pages.
import asyncHandler from '../utils/asyncHandler.js';
import RainEvent from '../models/RainEvent.js';

// Rough "water saved" estimate: assumes a fixed roof area and a typical
// rainfall depth per detected rain spell. This is clearly an estimate for
// demo/education purposes, not a metered measurement - see ROOF_AREA_SQM,
// RAINFALL_DEPTH_MM and COLLECTION_EFFICIENCY in backend/.env
const estimateWaterSavedLiters = (rainEventCount) => {
  const roofArea = Number(process.env.ROOF_AREA_SQM || 100); // m^2
  const rainfallDepthM = Number(process.env.RAINFALL_DEPTH_MM || 5) / 1000; // mm -> m
  const efficiency = Number(process.env.COLLECTION_EFFICIENCY || 0.8);
  const litersPerEvent = roofArea * rainfallDepthM * 1000 * efficiency; // 1 m^3 = 1000 L
  return Math.round(rainEventCount * litersPerEvent);
};

// @route  GET /api/dashboard/stats
// @access Private
export const getStats = asyncHandler(async (req, res) => {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);

  const [latest, todayCount, totalCount] = await Promise.all([
    RainEvent.findOne().sort({ timestamp: -1 }),
    RainEvent.countDocuments({ rainDetected: true, timestamp: { $gte: startOfToday } }),
    RainEvent.countDocuments({ rainDetected: true }),
  ]);

  const currentlyRaining = !!(latest && latest.rainDetected && latest.duration === null);

  // --- Last 7 days, grouped by day (for the "weekly" chart) ---
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  sevenDaysAgo.setHours(0, 0, 0, 0);

  const weeklyRaw = await RainEvent.aggregate([
    { $match: { rainDetected: true, timestamp: { $gte: sevenDaysAgo } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$timestamp' } },
        count: { $sum: 1 },
        avgSensorValue: { $avg: '$sensorValue' },
      },
    },
    { $sort: { _id: 1 } },
  ]);

  // --- Last 6 months, grouped by month (for the "monthly" chart) ---
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
  sixMonthsAgo.setDate(1);
  sixMonthsAgo.setHours(0, 0, 0, 0);

  const monthlyRaw = await RainEvent.aggregate([
    { $match: { rainDetected: true, timestamp: { $gte: sixMonthsAgo } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m', date: '$timestamp' } },
        count: { $sum: 1 },
      },
    },
    { $sort: { _id: 1 } },
  ]);

  const [avgResult] = await RainEvent.aggregate([
    { $match: { rainDetected: true } },
    { $group: { _id: null, avgSensorValue: { $avg: '$sensorValue' } } },
  ]);

  res.json({
    success: true,
    currentStatus: {
      rainDetected: currentlyRaining,
      sensorValue: latest?.sensorValue ?? null,
      buzzerStatus: currentlyRaining,
      lastDetectionTime: latest?.timestamp ?? null,
    },
    todayEventCount: todayCount,
    totalEventCount: totalCount,
    waterSavedLiters: estimateWaterSavedLiters(totalCount),
    averageSensorValue: avgResult ? Math.round(avgResult.avgSensorValue) : 0,
    weeklyData: weeklyRaw.map((d) => ({ date: d._id, count: d.count, avgSensorValue: Math.round(d.avgSensorValue) })),
    monthlyData: monthlyRaw.map((d) => ({ month: d._id, count: d.count })),
  });
});

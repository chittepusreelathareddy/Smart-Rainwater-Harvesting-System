// Admin-only endpoints: manage users, view system-wide stats
import asyncHandler from '../utils/asyncHandler.js';
import User from '../models/User.js';
import RainEvent from '../models/RainEvent.js';

// @route  GET /api/admin/users
// @access Private (admin)
export const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find().sort({ createdAt: -1 });
  res.json({ success: true, count: users.length, users });
});

// @route  DELETE /api/admin/users/:id
// @access Private (admin)
export const deleteUser = asyncHandler(async (req, res) => {
  if (req.params.id === req.user.id) {
    res.status(400);
    throw new Error('You cannot delete your own account while logged in');
  }
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  await user.deleteOne();
  res.json({ success: true, message: 'User removed' });
});

// @route  GET /api/admin/system-stats
// @access Private (admin)
export const getSystemStats = asyncHandler(async (req, res) => {
  const [userCount, adminCount, totalEvents, rainEvents] = await Promise.all([
    User.countDocuments({ role: 'user' }),
    User.countDocuments({ role: 'admin' }),
    RainEvent.countDocuments(),
    RainEvent.countDocuments({ rainDetected: true }),
  ]);

  res.json({
    success: true,
    userCount,
    adminCount,
    totalEvents,
    rainEvents,
  });
});

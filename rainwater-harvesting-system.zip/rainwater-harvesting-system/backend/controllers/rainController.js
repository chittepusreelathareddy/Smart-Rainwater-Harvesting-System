// Handles incoming sensor readings from the device, and lets the frontend
// read/manage rain event history. See models/RainEvent.js for the design
// note on why one "spell" = one document, not one document per sensor ping.
import asyncHandler from '../utils/asyncHandler.js';
import RainEvent from '../models/RainEvent.js';

// Shared logic used by both the real device endpoint and the "simulate" endpoint.
const recordReading = async (sensorValue, rainDetected) => {
  const latest = await RainEvent.findOne().sort({ timestamp: -1 });
  const hasOpenSpell = latest && latest.rainDetected === true && latest.duration === null;

  if (rainDetected) {
    if (hasOpenSpell) {
      // Rain is still going - just update the reading on the existing open spell
      latest.sensorValue = sensorValue;
      await latest.save();
      return { event: latest, action: 'updated' };
    }
    // A brand new rain spell is starting
    const event = await RainEvent.create({
      sensorValue,
      rainDetected: true,
      buzzerStatus: true,
      timestamp: new Date(),
      duration: null,
    });
    return { event, action: 'started' };
  }

  // rainDetected === false
  if (hasOpenSpell) {
    // The spell that was open has just ended - close it out
    latest.duration = Date.now() - new Date(latest.timestamp).getTime();
    latest.buzzerStatus = false;
    await latest.save();
    return { event: latest, action: 'stopped' };
  }

  // No open spell and no rain - nothing to record, this is a normal "all clear" ping
  return { event: latest || null, action: 'idle' };
};

// @route  POST /api/rain/add
// @access Device (x-device-key header, see middleware/deviceAuth.js)
// This is what the Arduino/ESP32 calls on every sensor poll.
export const addReading = asyncHandler(async (req, res) => {
  const { sensorValue, rainDetected } = req.body;
  const result = await recordReading(sensorValue, rainDetected);
  res.status(201).json({ success: true, ...result });
});

// @route  POST /api/rain/simulate
// @access Private (any logged-in user)
// Lets you test the whole system from the UI without any real hardware -
// see the "Simulate Rain Event" button on the Rain Monitoring page.
export const simulateReading = asyncHandler(async (req, res) => {
  const { rainDetected } = req.body;
  const sensorValue = rainDetected ? Math.floor(300 + Math.random() * 400) : Math.floor(Math.random() * 100);
  const result = await recordReading(sensorValue, rainDetected);
  res.status(201).json({ success: true, ...result });
});

// @route  GET /api/rain/history
// @access Private
export const getHistory = asyncHandler(async (req, res) => {
  const events = await RainEvent.find().sort({ timestamp: -1 }).limit(200);
  res.json({ success: true, count: events.length, events });
});

// @route  GET /api/rain/latest
// @access Private
export const getLatest = asyncHandler(async (req, res) => {
  const latest = await RainEvent.findOne().sort({ timestamp: -1 });
  const currentlyRaining = !!(latest && latest.rainDetected && latest.duration === null);

  res.json({
    success: true,
    latest: latest || null,
    currentlyRaining,
    buzzerStatus: currentlyRaining,
  });
});

// @route  DELETE /api/rain/:id
// @access Private (admin)
export const deleteEvent = asyncHandler(async (req, res) => {
  const event = await RainEvent.findById(req.params.id);
  if (!event) {
    res.status(404);
    throw new Error('Rain event not found');
  }
  await event.deleteOne();
  res.json({ success: true, message: 'Rain event removed' });
});

// @route  GET /api/rain/export
// @access Private (admin)
// Returns the full rain event history as a downloadable CSV file
export const exportHistory = asyncHandler(async (req, res) => {
  const events = await RainEvent.find().sort({ timestamp: -1 });

  const header = 'Date,Time,Sensor Value,Rain Detected,Buzzer Status,Duration (seconds)\n';
  const rows = events.map((e) => {
    const date = new Date(e.timestamp);
    const durationSec = e.duration !== null ? Math.round(e.duration / 1000) : '';
    return [
      date.toLocaleDateString(),
      date.toLocaleTimeString(),
      e.sensorValue,
      e.rainDetected,
      e.buzzerStatus,
      durationSec,
    ].join(',');
  });

  const csv = header + rows.join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="rain-events-export.csv"');
  res.send(csv);
});

// A logged-in user's own profile: view, update, change password
import asyncHandler from '../utils/asyncHandler.js';
import User from '../models/User.js';

// @route  GET /api/user/profile
// @access Private
export const getProfile = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user });
});

// @route  PUT /api/user/profile
// @access Private
export const updateProfile = asyncHandler(async (req, res) => {
  const { name } = req.body;
  const user = await User.findById(req.user.id);

  if (name) user.name = name;

  const updated = await user.save();
  res.json({
    success: true,
    user: { id: updated._id, name: updated.name, email: updated.email, role: updated.role },
  });
});

// @route  PUT /api/user/change-password
// @access Private
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user.id).select('+password');
  const isMatch = await user.matchPassword(currentPassword);

  if (!isMatch) {
    res.status(400);
    throw new Error('Current password is incorrect');
  }

  user.password = newPassword; // hashed automatically by the pre-save hook
  await user.save();

  res.json({ success: true, message: 'Password updated successfully' });
});

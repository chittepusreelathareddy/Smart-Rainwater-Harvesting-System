// RainEvent model - represents one continuous "rain spell" detected by the sensor.
//
// Design note: the ESP32 polls the sensor every few seconds and pings the
// backend continuously, but we don't want a new database row for every
// single ping (that would flood the database with thousands of near-
// identical rows per rainstorm). Instead:
//   - When rain STARTS, a new document is created with duration = null (open).
//   - While rain CONTINUES, that same open document's sensorValue is updated.
//   - When rain STOPS, that document's duration is filled in and it's closed.
// See controllers/rainController.js for the exact logic.
import mongoose from 'mongoose';

const rainEventSchema = new mongoose.Schema(
  {
    sensorValue: {
      type: Number,
      required: [true, 'Sensor value is required'],
    },
    rainDetected: {
      type: Boolean,
      required: true,
      default: false,
    },
    buzzerStatus: {
      type: Boolean,
      default: false,
    },
    timestamp: {
      type: Date,
      default: Date.now, // when this rain spell started
    },
    // Length of the rain spell in milliseconds. null while the spell is
    // still ongoing (buzzer currently on), filled in once rain stops.
    duration: {
      type: Number,
      default: null,
    },
  },
  { timestamps: true }
);

export default mongoose.model('RainEvent', rainEventSchema);

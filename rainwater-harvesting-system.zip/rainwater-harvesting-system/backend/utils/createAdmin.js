// One-off script to create the first admin account.
// Run with: npm run seed:admin
// Reads ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD from backend/.env
import 'dotenv/config';
import mongoose from 'mongoose';
import connectDB from '../config/db.js';
import User from '../models/User.js';

const run = async () => {
  await connectDB();

  const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;

  if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD) {
    console.error('Please set ADMIN_NAME, ADMIN_EMAIL and ADMIN_PASSWORD in backend/.env first');
    process.exit(1);
  }

  const existing = await User.findOne({ email: ADMIN_EMAIL });
  if (existing) {
    console.log(`An account with email ${ADMIN_EMAIL} already exists (role: ${existing.role}).`);
    process.exit(0);
  }

  await User.create({ name: ADMIN_NAME, email: ADMIN_EMAIL, password: ADMIN_PASSWORD, role: 'admin' });

  console.log(`Admin account created: ${ADMIN_EMAIL}`);
  await mongoose.disconnect();
  process.exit(0);
};

run();

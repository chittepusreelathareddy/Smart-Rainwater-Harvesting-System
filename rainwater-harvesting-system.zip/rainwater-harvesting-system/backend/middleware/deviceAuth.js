// Separate, lightweight auth for the physical Arduino/ESP32 device.
// The device can't do a real login flow, so instead it sends a shared
// secret in the "x-device-key" header on every request to POST /api/rain/add.
// This is intentionally simple - see the README for production hardening ideas
// (e.g. per-device keys, HTTPS-only, rotating keys).
const deviceAuth = (req, res, next) => {
  const key = req.headers['x-device-key'];

  if (!key || key !== process.env.DEVICE_API_KEY) {
    res.status(401);
    throw new Error('Invalid or missing device key');
  }

  next();
};

export default deviceAuth;

/*
  Smart Rainwater Harvesting Automation System
  Arduino Uno (no WiFi) firmware - reads the rain sensor and drives the
  buzzer locally, and prints readings over USB Serial in a simple format
  that a small script on your computer can forward to the backend.

  This is the option for people who only have a plain Arduino Uno (no WiFi
  module). If you have an ESP32, use ../ESP32_RainSensor/ESP32_RainSensor.ino
  instead - it talks to the backend directly over WiFi and needs no bridge.

  WIRING - same as the ESP32 version, but using Arduino Uno pins:
    Rain sensor AO -> A0
    Buzzer +       -> D8 (through a transistor/relay if needed)

  BRIDGING SERIAL DATA TO THE BACKEND
  ------------------------------------
  This sketch prints one line per reading to Serial, like:
      READING,412,1
  (sensorValue, rainDetected as 1/0)

  On your computer, a small Node.js script using the "serialport" npm
  package can read these lines and POST them to the same
  POST /api/rain/add endpoint the ESP32 uses - forward each line as:
      { sensorValue: 412, rainDetected: true }
  with the same "x-device-key" header. This project doesn't include that
  bridge script by default (to keep the backend hardware-agnostic), but it's
  a small script if you want to build one - roughly:

    const { SerialPort } = require('serialport');
    const { ReadlineParser } = require('@serialport/parser-readline');
    const axios = require('axios');
    const port = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 9600 });
    const parser = port.pipe(new ReadlineParser());
    parser.on('data', async (line) => {
      const [, value, detected] = line.trim().split(',');
      await axios.post('http://localhost:5000/api/rain/add',
        { sensorValue: Number(value), rainDetected: detected === '1' },
        { headers: { 'x-device-key': 'YOUR_DEVICE_KEY' } }
      );
    });
*/

const int RAIN_SENSOR_PIN = A0;
const int BUZZER_PIN = 8;

// Adjust based on your sensor: this example assumes LOWER analog value = MORE rain
const int RAIN_THRESHOLD = 500;
const unsigned long READ_INTERVAL_MS = 5000;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
}

void loop() {
  int sensorValue = analogRead(RAIN_SENSOR_PIN);
  bool rainDetected = sensorValue < RAIN_THRESHOLD;

  digitalWrite(BUZZER_PIN, rainDetected ? HIGH : LOW);

  Serial.print("READING,");
  Serial.print(sensorValue);
  Serial.print(",");
  Serial.println(rainDetected ? 1 : 0);

  delay(READ_INTERVAL_MS);
}

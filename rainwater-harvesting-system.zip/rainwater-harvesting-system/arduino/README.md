# Arduino / ESP32 firmware

Two options are included, depending on your hardware:

## Option A — ESP32 (recommended)
`ESP32_RainSensor/ESP32_RainSensor.ino`

Connects to WiFi and POSTs sensor readings directly to the backend's
`POST /api/rain/add` endpoint. No extra software needed on your computer.

**Setup:**
1. Open the file in the Arduino IDE (install the ESP32 board package first:
   File → Preferences → Additional Board Manager URLs →
   `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`,
   then Tools → Board → Boards Manager → search "esp32" → install).
2. Fill in `WIFI_SSID`, `WIFI_PASSWORD`, `SERVER_URL` (your backend's IP + port),
   and `DEVICE_KEY` (must match `DEVICE_API_KEY` in `backend/.env`).
3. Select your ESP32 board under Tools → Board, select the right Port, and upload.
4. Open the Serial Monitor (115200 baud) to watch readings and confirm the
   backend responds with `200`/`201`.

## Option B — Arduino Uno (no WiFi)
`Arduino_Uno_Serial/Arduino_Uno_Serial.ino`

Reads the sensor and drives the buzzer locally, and prints readings over USB
Serial. Since a plain Uno has no WiFi, getting data to the backend requires a
small bridge script running on your computer (see the comment at the top of
the .ino file for a ready-to-adapt example using the `serialport` npm
package). This keeps the backend itself hardware-agnostic - it doesn't care
whether readings come from an ESP32 directly or a Uno via a bridge script, as
long as the request looks the same.

## Testing without any hardware at all

The web app also has a "Simulate Rain Event" panel on the Rain Monitoring
page (calls a JWT-protected `POST /api/rain/simulate` endpoint), so you can
try out the whole system - dashboard, buzzer status, history, analytics -
before you've wired anything up.

## Calibrating the threshold

Rain sensor boards vary. Open the Serial Monitor, note the analog value when
the sensor is completely dry vs. lightly misted with water, and set
`RAIN_THRESHOLD` roughly halfway between the two. Most boards read a HIGH
value when dry and the value drops as water bridges the sensor track - if
yours behaves the opposite way, flip the comparison (`>` instead of `<`) in
the `.ino` file.

/*
  Smart Rainwater Harvesting Automation System
  ESP32 firmware - reads a rain sensor, drives a buzzer, and reports
  readings to the Node.js backend over WiFi.

  WIRING
  ------
  Rain sensor (analog rain board + comparator module):
    VCC  -> 3.3V (or 5V if your module is 5V tolerant - check its datasheet)
    GND  -> GND
    AO   -> ESP32 analog pin (see RAIN_SENSOR_PIN below)

  Buzzer (active buzzer):
    +    -> ESP32 digital pin (see BUZZER_PIN below), through a transistor/
            relay if it draws more current than the GPIO can supply directly
    -    -> GND

  HOW IT WORKS
  ------------
  1. Every READ_INTERVAL_MS, read the analog rain sensor.
  2. Most rain sensor boards read a HIGH voltage (large analog value) when
     DRY, and the value DROPS as water bridges the sensor track. Adjust
     RAIN_THRESHOLD and the comparison direction below to match your specific
     module if it behaves the other way around.
  3. If rain is detected: turn the buzzer on, and POST the reading to the
     backend with rainDetected = true.
  4. If no rain: turn the buzzer off, and POST rainDetected = false.
  5. The backend (see backend/controllers/rainController.js) is smart about
     not creating a new database row for every single reading - it just
     updates the current "rain spell" until the rain stops.
*/

#include <WiFi.h>
#include <HTTPClient.h>

// ---------- CONFIG: fill these in ----------
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// Use your backend's local network IP (e.g. http://192.168.1.50:5000) when
// testing on the same WiFi, or your deployed backend URL in production.
const char* SERVER_URL   = "http://192.168.1.50:5000/api/rain/add";
const char* DEVICE_KEY   = "replace_this_with_a_long_random_device_key"; // must match DEVICE_API_KEY in backend/.env

// ---------- CONFIG: pins & thresholds ----------
const int RAIN_SENSOR_PIN = 34;   // any ADC-capable pin on the ESP32
const int BUZZER_PIN      = 26;   // any digital output pin

// Adjust based on your sensor: this example assumes LOWER analog value = MORE rain
const int RAIN_THRESHOLD    = 500; // below this value, we consider it "raining"
const unsigned long READ_INTERVAL_MS = 5000; // how often to poll the sensor

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  connectToWiFi();
}

void loop() {
  int sensorValue = analogRead(RAIN_SENSOR_PIN);
  bool rainDetected = sensorValue < RAIN_THRESHOLD;

  digitalWrite(BUZZER_PIN, rainDetected ? HIGH : LOW);

  Serial.printf("Sensor: %d | Rain detected: %s\n", sensorValue, rainDetected ? "YES" : "no");

  sendReading(sensorValue, rainDetected);

  delay(READ_INTERVAL_MS);
}

void connectToWiFi() {
  Serial.printf("Connecting to WiFi \"%s\"...\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void sendReading(int sensorValue, bool rainDetected) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi disconnected, attempting to reconnect...");
    connectToWiFi();
    return;
  }

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("x-device-key", DEVICE_KEY);

  // Build a small JSON body by hand to avoid needing an extra library
  String payload = String("{\"sensorValue\":") + sensorValue +
                    ",\"rainDetected\":" + (rainDetected ? "true" : "false") + "}";

  int responseCode = http.POST(payload);

  if (responseCode > 0) {
    Serial.printf("Server response [%d]: %s\n", responseCode, http.getString().c_str());
  } else {
    Serial.printf("POST failed, error: %s\n", http.errorToString(responseCode).c_str());
  }

  http.end();
}

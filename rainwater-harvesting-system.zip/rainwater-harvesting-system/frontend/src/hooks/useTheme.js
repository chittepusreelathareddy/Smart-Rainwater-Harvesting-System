import { useThemeContext } from '../context/ThemeContext.jsx';

const useTheme = () => useThemeContext();

export default useTheme;

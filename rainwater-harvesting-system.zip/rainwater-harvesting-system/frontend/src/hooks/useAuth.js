// Thin wrapper so pages can `import { useAuth } from '../hooks/useAuth.js'`
// without needing to know the context lives in AuthContext.jsx
import { useAuthContext } from '../context/AuthContext.jsx';

const useAuth = () => useAuthContext();

export default useAuth;

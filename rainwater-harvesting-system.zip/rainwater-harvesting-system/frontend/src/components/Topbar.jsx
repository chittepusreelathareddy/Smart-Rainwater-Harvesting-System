// Top bar shown above the page content on authenticated pages: mobile menu
// toggle, dark mode toggle, user info, logout.
import { Menu, Moon, Sun, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth.js';
import useTheme from '../hooks/useTheme.js';

const Topbar = ({ onMenuClick }) => {
  const { user, logout } = useAuth();
  const { darkMode, toggleDarkMode } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="glass-card mb-6 flex items-center justify-between rounded-2xl px-4 py-3 sm:px-6">
      <button onClick={onMenuClick} className="text-slate-600 dark:text-slate-300 lg:hidden">
        <Menu size={22} />
      </button>

      <div className="hidden text-sm text-slate-500 dark:text-slate-400 lg:block">
        Welcome back, <span className="font-semibold text-slate-800 dark:text-slate-100">{user?.name}</span>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <button onClick={toggleDarkMode} className="btn-secondary !px-2 !py-2" title="Toggle dark mode">
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>
        <span className="hidden rounded-full bg-primary-50 px-3 py-1 text-xs font-medium capitalize text-primary-700 dark:bg-white/10 dark:text-primary-300 sm:inline">
          {user?.role}
        </span>
        <button onClick={handleLogout} className="btn-secondary flex items-center gap-1.5">
          <LogOut size={15} /> <span className="hidden sm:inline">Log out</span>
        </button>
      </div>
    </header>
  );
};

export default Topbar;

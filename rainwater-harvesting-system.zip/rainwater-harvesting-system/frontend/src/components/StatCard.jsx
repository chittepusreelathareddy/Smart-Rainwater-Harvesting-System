// Glassmorphism stat card used across the Dashboard page
const StatCard = ({ icon: Icon, label, value, accent = 'text-primary-600' }) => (
  <div className="glass-card flex items-center gap-4 p-5">
    {Icon && (
      <div className={`rounded-xl bg-primary-50 p-3 dark:bg-white/10 ${accent}`}>
        <Icon size={22} />
      </div>
    )}
    <div>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">{label}</p>
      <p className="mt-1 text-xl font-bold text-slate-800 dark:text-slate-100">{value}</p>
    </div>
  </div>
);

export default StatCard;

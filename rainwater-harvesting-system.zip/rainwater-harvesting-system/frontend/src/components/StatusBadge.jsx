// Small colored pill, used for rain status / buzzer status / role labels
const VARIANTS = {
  success: 'bg-green-100 text-green-800 dark:bg-green-500/20 dark:text-green-300',
  danger: 'bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300',
  warning: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-500/20 dark:text-yellow-300',
  neutral: 'bg-slate-100 text-slate-700 dark:bg-white/10 dark:text-slate-300',
};

const StatusBadge = ({ label, variant = 'neutral' }) => (
  <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${VARIANTS[variant]}`}>
    {label}
  </span>
);

export default StatusBadge;

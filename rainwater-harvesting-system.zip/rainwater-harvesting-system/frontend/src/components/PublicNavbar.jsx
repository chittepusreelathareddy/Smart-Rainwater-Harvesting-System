// Simple top navbar used only on the public Home page
import { Link } from 'react-router-dom';
import { CloudRain, Moon, Sun } from 'lucide-react';
import useTheme from '../hooks/useTheme.js';

const PublicNavbar = () => {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <nav className="glass-card sticky top-4 z-20 mx-4 mt-4 flex items-center justify-between rounded-2xl px-6 py-3 sm:mx-8">
      <Link to="/" className="flex items-center gap-2 text-lg font-bold text-primary-700 dark:text-primary-400">
        <CloudRain size={22} />
        Smart Rainwater Harvesting
      </Link>
      <div className="flex items-center gap-3">
        <button onClick={toggleDarkMode} className="btn-secondary !px-2 !py-2">
          {darkMode ? <Sun size={16} /> : <Moon size={16} />}
        </button>
        <Link to="/login" className="btn-secondary">Log in</Link>
        <Link to="/register" className="btn-primary">Get Started</Link>
      </div>
    </nav>
  );
};

export default PublicNavbar;

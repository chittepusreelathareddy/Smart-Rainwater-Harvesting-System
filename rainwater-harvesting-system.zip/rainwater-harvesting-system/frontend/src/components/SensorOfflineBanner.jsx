// Warns the user if no sensor reading has come in recently - one of the two
// "Main Features" notifications (rain-detected is a toast, this is a banner).
import { AlertTriangle } from 'lucide-react';

const OFFLINE_MINUTES = 10;

const SensorOfflineBanner = ({ lastReadingTime }) => {
  if (!lastReadingTime) {
    return (
      <div className="mb-4 flex items-center gap-2 rounded-xl border border-yellow-300 bg-yellow-50 px-4 py-3 text-sm text-yellow-800 dark:border-yellow-500/30 dark:bg-yellow-500/10 dark:text-yellow-300">
        <AlertTriangle size={16} />
        No sensor readings yet. Connect your Arduino/ESP32, or use "Simulate Rain Event" on the Rain Monitoring page.
      </div>
    );
  }

  const minutesSince = (Date.now() - new Date(lastReadingTime).getTime()) / 60000;
  if (minutesSince < OFFLINE_MINUTES) return null;

  return (
    <div className="mb-4 flex items-center gap-2 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-800 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
      <AlertTriangle size={16} />
      Sensor may be offline — no reading received in over {OFFLINE_MINUTES} minutes.
    </div>
  );
};

export default SensorOfflineBanner;

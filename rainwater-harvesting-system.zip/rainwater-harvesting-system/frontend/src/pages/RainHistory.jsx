// Table of every recorded rain spell. Admins can delete events and export CSV.
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Trash2, Download } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import useAuth from '../hooks/useAuth.js';
import { getHistory, deleteEvent, exportHistoryCsv } from '../services/rainService.js';
import { formatDateTime, formatDuration } from '../utils/formatDate.js';

const RainHistory = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const load = () => {
    setLoading(true);
    getHistory()
      .then((data) => setEvents(data.events))
      .catch(() => toast.error('Could not load rain history'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleDelete = async (id) => {
    if (!confirm('Delete this rain event? This cannot be undone.')) return;
    try {
      await deleteEvent(id);
      toast.success('Event deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  const handleExport = async () => {
    try {
      const blob = await exportHistoryCsv();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'rain-events-export.csv';
      a.click();
      window.URL.revokeObjectURL(url);
    } catch {
      toast.error('Export failed');
    }
  };

  return (
    <DashboardLayout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Rain History</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Every recorded rain spell, most recent first.</p>
        </div>
        {user?.role === 'admin' && (
          <button onClick={handleExport} className="btn-secondary flex items-center gap-2">
            <Download size={16} /> Export CSV
          </button>
        )}
      </div>

      {loading ? (
        <Spinner />
      ) : (
        <div className="glass-card overflow-x-auto p-2">
          <table className="min-w-full text-sm">
            <thead className="text-left text-xs font-medium uppercase text-slate-500 dark:text-slate-400">
              <tr>
                <th className="px-4 py-3">Date &amp; Time</th>
                <th className="px-4 py-3">Sensor Value</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Buzzer</th>
                <th className="px-4 py-3">Duration</th>
                {user?.role === 'admin' && <th className="px-4 py-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/60 dark:divide-white/10">
              {events.map((e) => (
                <tr key={e._id}>
                  <td className="px-4 py-3 text-slate-700 dark:text-slate-200">{formatDateTime(e.timestamp)}</td>
                  <td className="px-4 py-3 text-slate-700 dark:text-slate-200">{e.sensorValue}</td>
                  <td className="px-4 py-3">
                    <StatusBadge label={e.rainDetected ? 'Rain' : 'Clear'} variant={e.rainDetected ? 'danger' : 'success'} />
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge label={e.buzzerStatus ? 'ON' : 'OFF'} variant={e.buzzerStatus ? 'warning' : 'neutral'} />
                  </td>
                  <td className="px-4 py-3 text-slate-700 dark:text-slate-200">{formatDuration(e.duration)}</td>
                  {user?.role === 'admin' && (
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => handleDelete(e._id)} className="text-red-600 hover:underline dark:text-red-400">
                        <Trash2 size={15} className="inline" /> Delete
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {events.length === 0 && (
                <tr>
                  <td colSpan={user?.role === 'admin' ? 6 : 5} className="px-4 py-8 text-center text-slate-400">
                    No rain events recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </DashboardLayout>
  );
};

export default RainHistory;

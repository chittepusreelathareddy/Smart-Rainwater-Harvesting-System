// Main authenticated landing page: shows current status + key stats.
import { useEffect, useRef, useState } from 'react';
import toast from 'react-hot-toast';
import { CloudRain, Gauge, Bell, Clock, CalendarDays, ListChecks, Droplets } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import StatCard from '../components/StatCard.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Spinner from '../components/Spinner.jsx';
import SensorOfflineBanner from '../components/SensorOfflineBanner.jsx';
import { getDashboardStats } from '../services/dashboardService.js';
import { formatDateTime, formatRelativeTime } from '../utils/formatDate.js';

const POLL_MS = 8000;

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const wasRaining = useRef(false); // tracks previous state so we only toast on the transition

  const load = async () => {
    try {
      const data = await getDashboardStats();
      setStats(data);

      // Fire a one-time "rain detected" toast when status flips from dry -> raining
      if (data.currentStatus.rainDetected && !wasRaining.current) {
        toast('🌧️ Rain detected! Buzzer activated.', { icon: '🔔' });
      }
      wasRaining.current = data.currentStatus.rainDetected;
    } catch {
      toast.error('Could not load dashboard stats');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, POLL_MS);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <DashboardLayout>
      <h1 className="mb-1 text-2xl font-bold text-slate-800 dark:text-slate-100">Dashboard</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">Live overview of your rainwater harvesting system.</p>

      {loading || !stats ? (
        <Spinner />
      ) : (
        <>
          <SensorOfflineBanner lastReadingTime={stats.currentStatus.lastDetectionTime} />

          {/* Current status banner */}
          <div className="glass-card mb-6 flex flex-wrap items-center justify-between gap-4 p-6">
            <div className="flex items-center gap-4">
              <div className={`rounded-2xl p-4 ${stats.currentStatus.rainDetected ? 'bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-300' : 'bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400'}`}>
                <CloudRain size={32} />
              </div>
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Current status</p>
                <p className="text-xl font-bold text-slate-800 dark:text-slate-100">
                  {stats.currentStatus.rainDetected ? 'Rain Detected' : 'No Rain'}
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <StatusBadge
                label={stats.currentStatus.rainDetected ? 'Rain: Detected' : 'Rain: Clear'}
                variant={stats.currentStatus.rainDetected ? 'danger' : 'success'}
              />
              <StatusBadge
                label={stats.currentStatus.buzzerStatus ? 'Buzzer: ON' : 'Buzzer: OFF'}
                variant={stats.currentStatus.buzzerStatus ? 'warning' : 'neutral'}
              />
            </div>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <StatCard icon={Gauge} label="Sensor Value" value={stats.currentStatus.sensorValue ?? '—'} />
            <StatCard icon={Bell} label="Buzzer Status" value={stats.currentStatus.buzzerStatus ? 'ON' : 'OFF'} />
            <StatCard icon={Clock} label="Last Detection" value={formatRelativeTime(stats.currentStatus.lastDetectionTime)} />
            <StatCard icon={CalendarDays} label="Today's Rain Events" value={stats.todayEventCount} />
            <StatCard icon={ListChecks} label="Total Rain Events" value={stats.totalEventCount} />
            <StatCard icon={Droplets} label="Water Saved (est.)" value={`${stats.waterSavedLiters.toLocaleString()} L`} />
          </div>

          <p className="mt-6 text-xs text-slate-400 dark:text-slate-500">
            Last detection: {formatDateTime(stats.currentStatus.lastDetectionTime)} • Refreshing every {POLL_MS / 1000}s
          </p>
        </>
      )}
    </DashboardLayout>
  );
};

export default Dashboard;

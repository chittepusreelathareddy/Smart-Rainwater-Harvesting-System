// View/update profile, change password
import { useState } from 'react';
import toast from 'react-hot-toast';
import DashboardLayout from '../components/DashboardLayout.jsx';
import useAuth from '../hooks/useAuth.js';
import { updateProfile, changePassword } from '../services/userService.js';

const Profile = () => {
  const { user, setUser } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [savingProfile, setSavingProfile] = useState(false);

  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' });
  const [savingPassword, setSavingPassword] = useState(false);

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const { user: updated } = await updateProfile({ name });
      setUser(updated);
      toast.success('Profile updated');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setSavingPassword(true);
    try {
      await changePassword(pwForm);
      toast.success('Password updated');
      setPwForm({ currentPassword: '', newPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Password update failed');
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <DashboardLayout>
      <h1 className="mb-6 text-2xl font-bold text-slate-800 dark:text-slate-100">Profile</h1>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <form onSubmit={handleProfileSubmit} className="glass-card p-6">
          <h2 className="mb-4 font-semibold text-slate-800 dark:text-slate-100">Your details</h2>

          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Full name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="input-field mb-4" />

          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
          <input value={user?.email} disabled className="input-field mb-4 opacity-60" />

          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Role</label>
          <input value={user?.role} disabled className="input-field mb-6 capitalize opacity-60" />

          <button type="submit" disabled={savingProfile} className="btn-primary">
            {savingProfile ? 'Saving...' : 'Save changes'}
          </button>
        </form>

        <form onSubmit={handlePasswordSubmit} className="glass-card p-6">
          <h2 className="mb-4 font-semibold text-slate-800 dark:text-slate-100">Change password</h2>

          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Current password</label>
          <input
            type="password" required value={pwForm.currentPassword}
            onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
            className="input-field mb-4"
          />

          <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">New password</label>
          <input
            type="password" required value={pwForm.newPassword}
            onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
            className="input-field mb-6"
          />

          <button type="submit" disabled={savingPassword} className="btn-primary">
            {savingPassword ? 'Updating...' : 'Update password'}
          </button>
        </form>
      </div>
    </DashboardLayout>
  );
};

export default Profile;

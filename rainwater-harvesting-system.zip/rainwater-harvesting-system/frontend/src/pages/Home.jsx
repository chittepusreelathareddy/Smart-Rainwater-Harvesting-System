// Public landing page - explains the system and links to login/register
import { Link } from 'react-router-dom';
import { CloudRain, Bell, BarChart3, ShieldCheck } from 'lucide-react';
import PublicNavbar from '../components/PublicNavbar.jsx';

const FEATURES = [
  { icon: CloudRain, title: 'Automatic Detection', text: 'A rain sensor connected to an ESP32/Arduino reports readings in real time.' },
  { icon: Bell, title: 'Instant Buzzer Alerts', text: 'The buzzer switches on the moment rain is detected, and off when it stops.' },
  { icon: BarChart3, title: 'Rich Analytics', text: 'Daily, weekly and monthly rain trends, charted automatically.' },
  { icon: ShieldCheck, title: 'Admin Controls', text: 'Manage users, review history, and export reports from one dashboard.' },
];

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-slate-50 to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <PublicNavbar />

      <section className="mx-auto max-w-4xl px-6 py-20 text-center">
        <h1 className="text-4xl font-extrabold leading-tight text-slate-800 dark:text-slate-100 sm:text-5xl">
          Smart Rainwater Harvesting
          <br className="hidden sm:block" />
          <span className="text-primary-600 dark:text-primary-400">Automation System</span>
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-slate-600 dark:text-slate-400">
          Monitor rainfall in real time, automate your buzzer alert, and track how much water your
          harvesting setup is helping you save — all from one dashboard.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link to="/register" className="btn-primary px-6 py-3 text-base">Get Started</Link>
          <Link to="/login" className="btn-secondary px-6 py-3 text-base">Log in</Link>
        </div>
      </section>

      <section className="mx-auto grid max-w-5xl grid-cols-1 gap-5 px-6 pb-24 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map(({ icon: Icon, title, text }) => (
          <div key={title} className="glass-card p-6">
            <Icon className="mb-3 text-primary-600 dark:text-primary-400" size={26} />
            <h3 className="mb-1 font-semibold text-slate-800 dark:text-slate-100">{title}</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">{text}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Home;

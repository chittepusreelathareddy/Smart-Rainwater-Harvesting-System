// App-level preferences: currently just dark mode, with a notification
// preview so the "Notification System" feature is visible and testable.
import toast from 'react-hot-toast';
import { Moon, Sun, Bell } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import useTheme from '../hooks/useTheme.js';

const Settings = () => {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <DashboardLayout>
      <h1 className="mb-6 text-2xl font-bold text-slate-800 dark:text-slate-100">Settings</h1>

      <div className="glass-card mb-6 flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          {darkMode ? <Moon className="text-primary-500" /> : <Sun className="text-primary-500" />}
          <div>
            <p className="font-medium text-slate-800 dark:text-slate-100">Dark mode</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Switch between light and dark theme.</p>
          </div>
        </div>
        <button
          onClick={toggleDarkMode}
          className={`h-7 w-12 rounded-full transition ${darkMode ? 'bg-primary-600' : 'bg-slate-300'}`}
        >
          <span className={`block h-5 w-5 translate-y-1 rounded-full bg-white shadow transition ${darkMode ? 'translate-x-6' : 'translate-x-1'}`} />
        </button>
      </div>

      <div className="glass-card p-6">
        <div className="mb-3 flex items-center gap-3">
          <Bell className="text-primary-500" />
          <div>
            <p className="font-medium text-slate-800 dark:text-slate-100">Notifications</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Rain-detected alerts show automatically as toasts on the Dashboard. A banner warns you if the
              sensor stops reporting. Tank-level and SMS/email alerts are on the roadmap — see the README.
            </p>
          </div>
        </div>
        <button onClick={() => toast('🌧️ This is what a rain alert looks like!')} className="btn-secondary">
          Preview a notification
        </button>
      </div>
    </DashboardLayout>
  );
};

export default Settings;

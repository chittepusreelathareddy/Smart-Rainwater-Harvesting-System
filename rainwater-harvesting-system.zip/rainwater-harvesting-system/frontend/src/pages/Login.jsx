import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { CloudRain } from 'lucide-react';
import useAuth from '../hooks/useAuth.js';

const Login = () => {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      toast.success(`Welcome back, ${user.name}!`);
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary-50 via-slate-50 to-slate-100 px-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <form onSubmit={handleSubmit} className="glass-card w-full max-w-sm p-8">
        <div className="mb-6 flex items-center gap-2 text-primary-700 dark:text-primary-400">
          <CloudRain size={22} />
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">Log in</h1>
        </div>

        <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
        <input name="email" type="email" required value={form.email} onChange={handleChange} className="input-field mb-4" />

        <label className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
        <input name="password" type="password" required value={form.password} onChange={handleChange} className="input-field mb-6" />

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? 'Logging in...' : 'Log in'}
        </button>

        <p className="mt-4 text-center text-sm text-slate-500 dark:text-slate-400">
          New here?{' '}
          <Link to="/register" className="font-medium text-primary-600 hover:underline dark:text-primary-400">
            Create an account
          </Link>
        </p>
      </form>
    </div>
  );
};

export default Login;

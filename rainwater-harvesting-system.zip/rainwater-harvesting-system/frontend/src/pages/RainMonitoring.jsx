// Real-time-ish view of the sensor: big status indicator, sensor gauge,
// buzzer status, and a "simulate" panel for testing without real hardware.
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { CloudRain, Bell, Play } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import Spinner from '../components/Spinner.jsx';
import SensorOfflineBanner from '../components/SensorOfflineBanner.jsx';
import { getLatestReading, simulateReading } from '../services/rainService.js';
import { formatDateTime } from '../utils/formatDate.js';

const POLL_MS = 4000;
const SENSOR_MAX = 800; // matches the simulated "rain" range in the backend, for the gauge bar

const RainMonitoring = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [simulating, setSimulating] = useState(false);

  const load = async () => {
    try {
      const result = await getLatestReading();
      setData(result);
    } catch {
      toast.error('Could not load sensor data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, POLL_MS);
    return () => clearInterval(interval);
  }, []);

  const handleSimulate = async (rainDetected) => {
    setSimulating(true);
    try {
      await simulateReading(rainDetected);
      toast.success(rainDetected ? 'Simulated: rain started' : 'Simulated: rain stopped');
      await load();
    } catch {
      toast.error('Simulation failed');
    } finally {
      setSimulating(false);
    }
  };

  const gaugePercent = data?.latest ? Math.min(100, Math.round((data.latest.sensorValue / SENSOR_MAX) * 100)) : 0;

  return (
    <DashboardLayout>
      <h1 className="mb-1 text-2xl font-bold text-slate-800 dark:text-slate-100">Rain Monitoring</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">Live sensor reading, refreshed every {POLL_MS / 1000}s.</p>

      {loading ? (
        <Spinner />
      ) : (
        <>
          <SensorOfflineBanner lastReadingTime={data?.latest?.timestamp} />

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Big status indicator */}
            <div className={`glass-card col-span-1 flex flex-col items-center justify-center p-8 text-center lg:col-span-1 ${data?.currentlyRaining ? 'ring-2 ring-blue-400' : ''}`}>
              <CloudRain size={56} className={data?.currentlyRaining ? 'text-blue-500' : 'text-slate-400'} />
              <p className="mt-4 text-2xl font-bold text-slate-800 dark:text-slate-100">
                {data?.currentlyRaining ? 'Rain Detected' : 'No Rain'}
              </p>
              <p className="mt-1 flex items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
                <Bell size={14} /> Buzzer: {data?.buzzerStatus ? 'ON' : 'OFF'}
              </p>
            </div>

            {/* Sensor gauge */}
            <div className="glass-card col-span-1 p-6 lg:col-span-2">
              <p className="mb-2 text-sm font-medium text-slate-600 dark:text-slate-300">Sensor value</p>
              <div className="mb-2 h-4 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${data?.currentlyRaining ? 'bg-blue-500' : 'bg-primary-400'}`}
                  style={{ width: `${gaugePercent}%` }}
                />
              </div>
              <p className="text-xs text-slate-400 dark:text-slate-500">
                {data?.latest ? `${data.latest.sensorValue} (${gaugePercent}% of scale)` : 'No reading yet'}
              </p>

              <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Last updated</p>
                  <p className="font-medium text-slate-800 dark:text-slate-100">{formatDateTime(data?.latest?.timestamp)}</p>
                </div>
                <div>
                  <p className="text-slate-500 dark:text-slate-400">Event status</p>
                  <p className="font-medium text-slate-800 dark:text-slate-100">
                    {data?.latest ? (data.latest.duration === null ? 'Ongoing' : 'Closed') : '—'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Simulation panel */}
          <div className="glass-card mt-6 p-6">
            <h2 className="mb-1 flex items-center gap-2 font-semibold text-slate-800 dark:text-slate-100">
              <Play size={18} /> Simulate Rain Event
            </h2>
            <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">
              No hardware connected yet? Use these buttons to test the full system end-to-end.
            </p>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => handleSimulate(true)} disabled={simulating} className="btn-primary">
                Start Rain
              </button>
              <button onClick={() => handleSimulate(false)} disabled={simulating} className="btn-secondary">
                Stop Rain
              </button>
            </div>
          </div>
        </>
      )}
    </DashboardLayout>
  );
};

export default RainMonitoring;

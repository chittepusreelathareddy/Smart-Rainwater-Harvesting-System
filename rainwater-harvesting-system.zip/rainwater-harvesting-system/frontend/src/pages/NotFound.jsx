import { Link } from 'react-router-dom';

const NotFound = () => (
  <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-slate-50 text-center dark:bg-slate-950">
    <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">404</h1>
    <p className="text-slate-500 dark:text-slate-400">This page doesn't exist.</p>
    <Link to="/" className="btn-primary mt-2">Go home</Link>
  </div>
);

export default NotFound;

// Admin-only page: system stats, user management
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Users, ShieldCheck, ListChecks, CloudRain, Trash2 } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout.jsx';
import StatCard from '../components/StatCard.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import Spinner from '../components/Spinner.jsx';
import useAuth from '../hooks/useAuth.js';
import { getAllUsers, deleteUser, getSystemStats } from '../services/adminService.js';
import { formatDateTime } from '../utils/formatDate.js';

const AdminDashboard = () => {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [systemStats, setSystemStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [usersData, statsData] = await Promise.all([getAllUsers(), getSystemStats()]);
      setUsers(usersData.users);
      setSystemStats(statsData);
    } catch {
      toast.error('Could not load admin data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleDeleteUser = async (id) => {
    if (!confirm('Remove this user account? This cannot be undone.')) return;
    try {
      await deleteUser(id);
      toast.success('User removed');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  return (
    <DashboardLayout>
      <h1 className="mb-1 text-2xl font-bold text-slate-800 dark:text-slate-100">Admin Dashboard</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">System-wide statistics and user management.</p>

      {loading ? (
        <Spinner />
      ) : (
        <>
          <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={Users} label="Users" value={systemStats.userCount} />
            <StatCard icon={ShieldCheck} label="Admins" value={systemStats.adminCount} />
            <StatCard icon={ListChecks} label="Total Events Logged" value={systemStats.totalEvents} />
            <StatCard icon={CloudRain} label="Rain Events" value={systemStats.rainEvents} />
          </div>

          <div className="glass-card overflow-x-auto p-2">
            <table className="min-w-full text-sm">
              <thead className="text-left text-xs font-medium uppercase text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Joined</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/60 dark:divide-white/10">
                {users.map((u) => (
                  <tr key={u._id}>
                    <td className="px-4 py-3 font-medium text-slate-800 dark:text-slate-100">{u.name}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{u.email}</td>
                    <td className="px-4 py-3">
                      <StatusBadge label={u.role} variant={u.role === 'admin' ? 'warning' : 'neutral'} />
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{formatDateTime(u.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      {u._id !== currentUser.id && (
                        <button onClick={() => handleDeleteUser(u._id)} className="text-red-600 hover:underline dark:text-red-400">
                          <Trash2 size={15} className="inline" /> Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">No users found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </DashboardLayout>
  );
};

export default AdminDashboard;

// Charts for daily/weekly/monthly rain trends, powered by Chart.js
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Bar, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Legend,
} from 'chart.js';
import DashboardLayout from '../components/DashboardLayout.jsx';
import StatCard from '../components/StatCard.jsx';
import Spinner from '../components/Spinner.jsx';
import { getDashboardStats } from '../services/dashboardService.js';
import { Droplets, Gauge, Bell } from 'lucide-react';

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Legend);

const chartOptions = {
  responsive: true,
  plugins: { legend: { display: false } },
  scales: {
    x: { grid: { display: false } },
    y: { beginAtZero: true, ticks: { precision: 0 } },
  },
};

const Analytics = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboardStats()
      .then(setStats)
      .catch(() => toast.error('Could not load analytics'))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return (
      <DashboardLayout>
        <Spinner />
      </DashboardLayout>
    );
  }

  const weeklyChart = {
    labels: stats.weeklyData.map((d) => d.date),
    datasets: [{ label: 'Rain events', data: stats.weeklyData.map((d) => d.count), backgroundColor: '#3b82f6', borderRadius: 6 }],
  };

  const monthlyChart = {
    labels: stats.monthlyData.map((d) => d.month),
    datasets: [{ label: 'Rain events', data: stats.monthlyData.map((d) => d.count), borderColor: '#2563eb', backgroundColor: '#93c5fd', tension: 0.3, fill: true }],
  };

  return (
    <DashboardLayout>
      <h1 className="mb-1 text-2xl font-bold text-slate-800 dark:text-slate-100">Analytics</h1>
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">Rain frequency trends and system-wide averages.</p>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard icon={Bell} label="Total Alerts" value={stats.totalEventCount} />
        <StatCard icon={Gauge} label="Average Sensor Value" value={stats.averageSensorValue} />
        <StatCard icon={Droplets} label="Water Saved (est.)" value={`${stats.waterSavedLiters.toLocaleString()} L`} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="glass-card p-6">
          <h2 className="mb-4 font-semibold text-slate-800 dark:text-slate-100">Daily rain detections (last 7 days)</h2>
          {stats.weeklyData.length > 0 ? <Bar data={weeklyChart} options={chartOptions} /> : <EmptyChart />}
        </div>

        <div className="glass-card p-6">
          <h2 className="mb-4 font-semibold text-slate-800 dark:text-slate-100">Monthly trend (last 6 months)</h2>
          {stats.monthlyData.length > 0 ? <Line data={monthlyChart} options={chartOptions} /> : <EmptyChart />}
        </div>
      </div>
    </DashboardLayout>
  );
};

const EmptyChart = () => (
  <p className="py-12 text-center text-sm text-slate-400 dark:text-slate-500">
    Not enough data yet — simulate a few rain events from the Rain Monitoring page.
  </p>
);

export default Analytics;

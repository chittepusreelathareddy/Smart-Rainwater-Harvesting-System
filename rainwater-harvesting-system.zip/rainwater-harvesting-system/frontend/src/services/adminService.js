import api from './api.js';

export const getAllUsers = () => api.get('/api/admin/users').then((r) => r.data);
export const deleteUser = (id) => api.delete(`/api/admin/users/${id}`).then((r) => r.data);
export const getSystemStats = () => api.get('/api/admin/system-stats').then((r) => r.data);

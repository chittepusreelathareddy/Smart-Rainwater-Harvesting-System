import api from './api.js';

export const getLatestReading = () => api.get('/api/rain/latest').then((r) => r.data);
export const getHistory = () => api.get('/api/rain/history').then((r) => r.data);
export const simulateReading = (rainDetected) =>
  api.post('/api/rain/simulate', { rainDetected }).then((r) => r.data);
export const deleteEvent = (id) => api.delete(`/api/rain/${id}`).then((r) => r.data);
export const exportHistoryCsv = () =>
  api.get('/api/rain/export', { responseType: 'blob' }).then((r) => r.data);

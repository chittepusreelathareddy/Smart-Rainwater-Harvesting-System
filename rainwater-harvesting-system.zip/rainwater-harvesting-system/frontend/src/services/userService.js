import api from './api.js';

export const getProfile = () => api.get('/api/user/profile').then((r) => r.data);
export const updateProfile = (data) => api.put('/api/user/profile', data).then((r) => r.data);
export const changePassword = (data) => api.put('/api/user/change-password', data).then((r) => r.data);

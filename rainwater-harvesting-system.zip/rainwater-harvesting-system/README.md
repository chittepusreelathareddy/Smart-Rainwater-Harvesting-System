# Smart Rainwater Harvesting Automation System

A full-stack IoT web app that monitors rainfall with a rain sensor connected
to an Arduino/ESP32. When rain is detected, it automatically triggers a
buzzer, updates a live dashboard, stores the event in MongoDB, and gives you
analytics on rain frequency over time.

**Stack:** React (Vite) + Tailwind CSS + Chart.js · Node.js + Express ·
MongoDB + Mongoose · JWT authentication · Arduino / ESP32 firmware

![screenshot placeholder: dashboard](docs/screenshots/dashboard.png)
![screenshot placeholder: rain monitoring](docs/screenshots/monitoring.png)
![screenshot placeholder: analytics](docs/screenshots/analytics.png)
*(Add your own screenshots to `docs/screenshots/` after running the app — these are placeholders.)*

---

## 1. Features

**Authentication** — register/login, JWT auth, bcrypt password hashing, protected routes, logout.

**Dashboard** — current rain status, sensor value, buzzer status, last detection time, today's/total rain events, estimated water saved, auto-refreshing status cards.

**Rain sensor module** — reads analog sensor values via Arduino/ESP32, classifies Rain Detected / No Rain, timestamps every reading, auto-triggers the buzzer.

**Buzzer control** — buzzer turns on the moment rain starts and off the moment it stops, status shown live on the dashboard, every activation logged as part of the event history.

**Rain event history** — every rain "spell" logged with date, time, sensor value, duration, and buzzer status; admins can delete events and export the full history as CSV.

**Analytics** — daily/weekly/monthly charts (Chart.js), average sensor value, total alert count.

**Admin dashboard** — view all users, remove accounts, view system-wide stats, export reports.

**Profile page** — update your name, change your password.

**Notifications** — a toast alert fires the moment rain is detected; a banner warns you if the sensor hasn't reported in a while (see "Future Features" below for SMS/email/tank-level alerts, which are out of scope for this version).

**UI** — glassmorphism cards, responsive layout, collapsible sidebar, dark mode, loading spinners, toast notifications.

---

## 2. What you need installed first

### Node.js
Download the **LTS** version from https://nodejs.org and install it. Confirm with:
```
node -v
npm -v
```

### MongoDB — pick one

**Option A — MongoDB Atlas (cloud, recommended)**
1. Create a free account at https://www.mongodb.com/cloud/atlas/register
2. Create a free "Shared" cluster.
3. Under **Database Access**, create a username/password.
4. Under **Network Access**, click "Allow Access from Anywhere" (fine for development).
5. Click "Connect" → "Drivers" and copy the connection string.

**Option B — MongoDB installed locally**
Install from https://www.mongodb.com/try/download/community — it typically
runs automatically at `mongodb://127.0.0.1:27017`, the default in this project.

### Arduino IDE (only if you have real hardware)
Download from https://www.arduino.cc/en/software — see `arduino/README.md` for board-specific setup.

---

## 3. Project structure

```
rainwater-harvesting-system/
├── backend/
│   ├── server.js                  # Express app entry point
│   ├── config/db.js               # MongoDB connection
│   ├── models/                    # User, RainEvent (Mongoose schemas)
│   ├── middleware/
│   │   ├── auth.js                # JWT verification + role-based access
│   │   ├── deviceAuth.js          # Shared-secret auth for the Arduino/ESP32
│   │   ├── validators.js          # express-validator rule sets
│   │   └── errorHandler.js        # Centralized error responses
│   ├── controllers/                # authController, userController, rainController,
│   │                                # dashboardController, adminController
│   ├── routes/                     # One Express router per resource
│   ├── utils/createAdmin.js       # Script to create the first admin account
│   └── .env.example
├── frontend/
│   └── src/
│       ├── services/               # api.js (axios instance) + one file per resource
│       ├── context/                # AuthContext, ThemeContext (dark mode)
│       ├── hooks/                  # useAuth, useTheme
│       ├── components/             # Sidebar, Topbar, DashboardLayout, StatCard, etc.
│       ├── pages/                  # Home, Login, Register, Dashboard, RainMonitoring,
│       │                            # RainHistory, Analytics, Profile, Settings, AdminDashboard
│       └── utils/formatDate.js
└── arduino/
    ├── ESP32_RainSensor/           # WiFi firmware (recommended)
    ├── Arduino_Uno_Serial/         # Serial-only firmware for boards without WiFi
    └── README.md                   # Wiring + calibration guide
```

### MongoDB schema

**User**
| Field | Type | Notes |
|---|---|---|
| name | String | required |
| email | String | required, unique |
| password | String | required, hashed with bcrypt, `select: false` |
| role | String | `user` \| `admin`, default `user` |

**RainEvent**
| Field | Type | Notes |
|---|---|---|
| sensorValue | Number | latest analog reading during this spell |
| rainDetected | Boolean | whether rain was detected |
| buzzerStatus | Boolean | whether the buzzer is/was on |
| timestamp | Date | when the rain spell started |
| duration | Number \| null | milliseconds the spell lasted; `null` while ongoing |

> **Design note:** one `RainEvent` document represents one continuous rain
> spell, not one row per sensor ping. While it's raining, the ESP32 can poll
> every few seconds without flooding the database — the backend just updates
> the same "open" document until rain stops and the spell is closed out with
> a `duration`. See the comments in `backend/models/RainEvent.js` and
> `backend/controllers/rainController.js` for the full logic.

### REST API reference

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register a new user |
| POST | `/api/auth/login` | Public | Log in, returns a JWT |
| GET | `/api/user/profile` | Private | Get own profile |
| PUT | `/api/user/profile` | Private | Update own name |
| PUT | `/api/user/change-password` | Private | Change own password |
| POST | `/api/rain/add` | Device (`x-device-key` header) | Arduino/ESP32 posts a sensor reading |
| POST | `/api/rain/simulate` | Private | Simulate a reading from the UI (no hardware needed) |
| GET | `/api/rain/history` | Private | List rain events (most recent 200) |
| GET | `/api/rain/latest` | Private | Get the current/most recent reading |
| DELETE | `/api/rain/:id` | Admin | Delete a rain event |
| GET | `/api/rain/export` | Admin | Download all rain events as CSV |
| GET | `/api/dashboard/stats` | Private | Aggregated stats for Dashboard/Analytics |
| GET | `/api/admin/users` | Admin | List all users |
| DELETE | `/api/admin/users/:id` | Admin | Remove a user account |
| GET | `/api/admin/system-stats` | Admin | User counts, total events, etc. |

All private routes require an `Authorization: Bearer <token>` header. The
device route uses a separate shared secret instead (see section 6 below).

---

## 4. Local setup, step by step

Unzip the project, e.g. into `Documents/rainwater-harvesting-system`.

### Step 1 — Backend

```bash
cd rainwater-harvesting-system/backend
npm install
cp .env.example .env
```

Open `backend/.env` and fill in real values — at minimum `MONGO_URI`,
`JWT_SECRET`, and `DEVICE_API_KEY` (make up any long random strings for the
last two). The `ROOF_AREA_SQM` / `RAINFALL_DEPTH_MM` / `COLLECTION_EFFICIENCY`
variables control the "water saved" estimate on the dashboard — adjust them
to roughly match your actual setup, or leave the defaults for a demo.

Create the first admin account:
```bash
npm run seed:admin
```

Start the backend:
```bash
npm run dev
```
You should see `MongoDB connected` and `Server running ... on port 5000`.

### Step 2 — Frontend

Open a **new terminal**, keeping the backend running:
```bash
cd rainwater-harvesting-system/frontend
npm install
cp .env.example .env
npm run dev
```
The default `VITE_API_URL=http://localhost:5000` is already correct if you
didn't change the backend port. Open the printed URL, typically `http://localhost:5173`.

### Step 3 — Try it out (no hardware needed)

1. Register a normal user account, or log in as admin with the credentials from `ADMIN_EMAIL`/`ADMIN_PASSWORD`.
2. Go to **Rain Monitoring** and click **Start Rain** — watch the dashboard, buzzer status, and history update.
3. Click **Stop Rain** — the event closes out with a duration.
4. Check **Rain History** for the logged spell, and **Analytics** for the chart.
5. As admin, check **Admin Dashboard** for system-wide stats and user management.

### Step 4 — Connect real hardware (optional)

See `arduino/README.md` for wiring, firmware setup, and threshold calibration
for either an ESP32 (WiFi, recommended) or a plain Arduino Uno (via a serial
bridge script).

---

## 5. Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection error` | Check `MONGO_URI` in `backend/.env`; for Atlas, confirm your IP is allowed under Network Access. |
| `npm run seed:admin` complains about missing fields | Set `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` in `backend/.env` first. |
| Frontend shows network errors on every request | Confirm the backend terminal is still running and `VITE_API_URL` matches its actual port. |
| ESP32 gets `401` from `/api/rain/add` | Its `DEVICE_KEY` must exactly match `DEVICE_API_KEY` in `backend/.env`. |
| ESP32 can't reach the backend | Make sure both are on the same network, and `SERVER_URL` uses your computer's local IP (not `localhost`), e.g. `http://192.168.1.50:5000`. |
| Charts show "not enough data" | Simulate a few rain events from the Rain Monitoring page first. |
| CORS errors in the browser console | Make sure `CLIENT_URL` in `backend/.env` matches the URL your frontend actually runs on. |

---

## 6. A note on IoT device security

`POST /api/rain/add` uses a simple shared secret (`x-device-key` header)
rather than a full JWT login, since a microcontroller can't easily do an
interactive login flow. This is fine for a home/hobby/prototype setup, but
before deploying at scale you may want to:
- Use HTTPS only (never send the device key over plain HTTP on an untrusted network)
- Use a unique key per device instead of one shared key
- Rotate the key periodically
- Rate-limit the endpoint

---

## 7. Deployment

- **Database:** MongoDB Atlas (you're likely already using it from local setup)
- **Backend:** Render
- **Frontend:** Vercel

### Deploy the backend (Render)

1. Push this project to a GitHub repository.
2. On https://render.com, click **New → Web Service**, connect your repo.
3. Set **Root directory:** `backend`, **Build command:** `npm install`, **Start command:** `npm start`.
4. Add every variable from `backend/.env.example` under **Environment**, with real values. Set `NODE_ENV=production` and `CLIENT_URL` to your (soon-to-exist) frontend URL.
5. Deploy, note the resulting URL (e.g. `https://rainwater-api.onrender.com`).
6. Run `npm run seed:admin` once via Render's shell tab, or temporarily locally against the production `MONGO_URI`.

### Deploy the frontend (Vercel)

1. On https://vercel.com, click **New Project**, import the same repo.
2. Set **Root directory:** `frontend`, **Build command:** `npm run build`, **Output directory:** `dist`.
3. Add environment variable `VITE_API_URL` pointing at your deployed backend URL.
4. Deploy, note the resulting URL (e.g. `https://rainwater-harvesting.vercel.app`).
5. Go back to the backend's environment variables on Render, update `CLIENT_URL` to this frontend URL, and redeploy the backend so CORS allows it.

### Pointing your ESP32 at production

Once deployed, update `SERVER_URL` in `ESP32_RainSensor.ino` to your Render
backend URL and re-upload the firmware — no other changes needed.

---

## 8. Future features (not implemented in this version)

These were intentionally left out of this build to keep scope focused, but
the architecture leaves room for them:
- Water level sensor + automatic pump control
- SMS alerts (e.g. via Twilio) and email alerts (e.g. via Nodemailer/SendGrid)
- Tank-full notifications
- Live ESP32 WiFi signal/health monitoring in the dashboard
- Weather API integration (e.g. cross-referencing sensor readings with forecast data)
- A dedicated mobile app (the current frontend is responsive and usable on mobile browsers today)

---

## License

MIT — see [LICENSE](LICENSE).
